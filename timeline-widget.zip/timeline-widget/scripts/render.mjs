#!/usr/bin/env node
/* ============================================================================
   Timeline Widget – generator SVG untuk README GitHub
   ----------------------------------------------------------------------------
   Menghasilkan dua file:
     widget.svg   – tampilan utama (kotak tanggal, tahun+bulan vertikal, jam,
                    daftar task, panel progres)
     history.svg  – laman riwayat (ringkasan bulan, statistik, diagram batang
                    harian, rincian hari ini, progres per task)

   Pemakaian:
     node scripts/render.mjs                  render ulang
     node scripts/render.mjs --toggle 2       centang/batal-centang task ke-2 hari ini
     node scripts/render.mjs --toggle 1,3     beberapa task sekaligus
   Variabel lingkungan (opsional, untuk uji):
     WIDGET_NOW=2026-10-18T23:59:50+07:00     paksa waktu sekarang
   Tanpa dependensi – hanya Node.js >= 18.
   ========================================================================== */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CONFIG_FILE = path.join(ROOT, 'data', 'config.json');
const LOG_FILE = path.join(ROOT, 'data', 'log.json');
const OUT_WIDGET = path.join(ROOT, 'widget.svg');
const OUT_HISTORY = path.join(ROOT, 'history.svg');

const readJSON = (f, fb) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fb; } };
const cfg = readJSON(CONFIG_FILE, {});
const TZ = cfg.timezone || 'Asia/Jakarta';
const TZ_LABEL = cfg.timezoneLabel || '';
const TASKS = (cfg.tasks && cfg.tasks.length ? cfg.tasks : [{ name: 'Task', detail: '' }]);
const QUOTE = cfg.quote || { author: '', text: '' };

/* ---------- Waktu (zona waktu dari config) ---------- */
const MONTHS = ['JANUARI', 'FEBRUARI', 'MARET', 'APRIL', 'MEI', 'JUNI', 'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER'];
const MON_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const DAYS = ['MINGGU', 'SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU'];
const WD = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

function nowParts() {
  const d = process.env.WIDGET_NOW ? new Date(process.env.WIDGET_NOW) : new Date();
  const f = new Intl.DateTimeFormat('en-US', {
    timeZone: TZ, year: 'numeric', month: 'numeric', day: 'numeric',
    hour: 'numeric', minute: 'numeric', weekday: 'short', hourCycle: 'h23'
  });
  const o = {};
  f.formatToParts(d).forEach(p => { o[p.type] = p.value; });
  return { y: +o.year, m: +o.month - 1, d: +o.day, hh: +o.hour % 24, mm: +o.minute, dow: WD[o.weekday] };
}
const pad2 = n => String(n).padStart(2, '0');
const keyOf = (y, m, d) => `${y}-${pad2(m + 1)}-${pad2(d)}`;
const daysIn = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
const dowOf = (y, m, d) => new Date(Date.UTC(y, m, d)).getUTCDay();
const ordinal = n => { const v = n % 100; if (v >= 11 && v <= 13) return 'TH'; return ({ 1: 'ST', 2: 'ND', 3: 'RD' })[n % 10] || 'TH'; };

/* ---------- Log harian (reset otomatis = kunci tanggal baru) ---------- */
const NOW = nowParts();
const todayKey = keyOf(NOW.y, NOW.m, NOW.d);
const log = readJSON(LOG_FILE, {});

/* Hari ini selalu mengikuti daftar task di config; hari lampau tidak diubah. */
const cur = log[todayKey] || { tasks: [], done: [] };
cur.tasks = TASKS.map(t => t.name);
cur.done = (cur.done || []).filter(i => Number.isInteger(i) && i >= 0 && i < TASKS.length);
log[todayKey] = cur;

const ti = process.argv.indexOf('--toggle');
if (ti > -1 && process.argv[ti + 1]) {
  String(process.argv[ti + 1]).split(/[,\s]+/).filter(Boolean).forEach(s => {
    const i = parseInt(s, 10) - 1;
    if (!(i >= 0 && i < TASKS.length)) return;
    const at = cur.done.indexOf(i);
    if (at > -1) cur.done.splice(at, 1); else cur.done.push(i);
  });
}
cur.done = [...new Set(cur.done)].sort((a, b) => a - b);

const sortedLog = {};
Object.keys(log).sort().forEach(k => { sortedLog[k] = log[k]; });
fs.writeFileSync(LOG_FILE, JSON.stringify(sortedLog, null, 1) + '\n');

/* Bentuk catatan: {tasks:[{n,d}]} */
const recOf = (y, m, d) => {
  const e = log[keyOf(y, m, d)];
  if (!e || !e.tasks || !e.tasks.length) return null;
  const set = new Set(e.done || []);
  return { tasks: e.tasks.map((n, i) => ({ n, d: set.has(i) ? 1 : 0 })) };
};
const pctOf = r => (!r ? 0 : Math.round(r.tasks.reduce((a, t) => a + t.d, 0) / r.tasks.length * 100));
const doneOf = r => (r ? r.tasks.reduce((a, t) => a + t.d, 0) : 0);

/* ---------- Util SVG ---------- */
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const f2 = n => (Math.round(n * 100) / 100).toString();
const FONT = "Arial, Helvetica, 'Liberation Sans', sans-serif";
const FONT_BLACK = "'Arial Black', 'Roboto Black', Impact, Arial, Helvetica, sans-serif";
const TEAL = '#00a99f', TEAL_L = '#55e4db';

/* Lebar maju huruf kapital Arial Bold (per 1000 em) – dipakai untuk menyebar huruf bulan */
const ADV = { A: 722, B: 722, C: 722, D: 722, E: 667, F: 611, G: 778, H: 722, I: 278, J: 556, K: 722, L: 611, M: 833, N: 722, O: 778, P: 667, Q: 778, R: 722, S: 667, T: 611, U: 722, V: 667, W: 944, X: 667, Y: 667, Z: 611 };

/* Angka jam tinggi-sempit (goresan rata) – kotak gambar 100 x 526 */
const DIGITS = {
  0: '<rect x="19" y="19" width="62" height="488" rx="31"/>',
  1: '<path d="M62 0V526M62 19H24M0 507H100"/>',
  2: '<path d="M19 110A31 91 0 0 1 81 110C81 260 19 300 19 430V507H100"/>',
  3: '<path d="M0 19H50A31 31 0 0 1 81 50V232A31 31 0 0 1 50 263H30M50 263A31 31 0 0 1 81 294V476A31 31 0 0 1 50 507H0"/>',
  4: '<path d="M19 0V300H100M69 0V526"/>',
  5: '<path d="M100 19H19V240H50A31 31 0 0 1 81 271V476A31 31 0 0 1 50 507H0"/>',
  6: '<path d="M96 19H50A31 31 0 0 0 19 50V476A31 31 0 0 0 50 507A31 31 0 0 0 81 476V294A31 31 0 0 0 50 263H19"/>',
  7: '<path d="M0 19H81V200L40 380V526"/>',
  8: '<rect x="19" y="19" width="62" height="244" rx="31"/><rect x="19" y="263" width="62" height="244" rx="31"/>',
  9: '<path transform="rotate(180 50 263)" d="M96 19H50A31 31 0 0 0 19 50V476A31 31 0 0 0 50 507A31 31 0 0 0 81 476V294A31 31 0 0 0 50 263H19"/>'
};
const digitDefs = () => '<g fill="none" stroke="#fff" stroke-width="38" stroke-linejoin="miter" stroke-linecap="butt">' +
  Object.entries(DIGITS).map(([k, v]) => `<g id="d${k}">${v}</g>`).join('') + '</g>';

function wrap(text, maxChars) {
  const words = String(text).split(/\s+/), lines = [];
  let l = '';
  words.forEach(w => {
    if ((l + ' ' + w).trim().length > maxChars && l) { lines.push(l); l = w; } else l = (l + ' ' + w).trim();
  });
  if (l) lines.push(l);
  return lines;
}

/* Kartu gelap bergradasi (dipakai panel progres & laman riwayat) */
function card(x, y, w, h, r, id, glowLeft = true, complete = false) {
  return `<g>` +
    `<rect x="${f2(x)}" y="${f2(y)}" width="${f2(w)}" height="${f2(h)}" rx="${f2(r)}" fill="url(#cardBg)"/>` +
    (glowLeft ? `<rect x="${f2(x)}" y="${f2(y)}" width="${f2(w)}" height="${f2(h)}" rx="${f2(r)}" fill="url(#cardGlow)"/>` : '') +
    `<rect x="${f2(x + .5)}" y="${f2(y + .5)}" width="${f2(w - 1)}" height="${f2(h - 1)}" rx="${f2(r)}" fill="none" stroke="${complete ? TEAL_L : '#26302f'}" stroke-width="${complete ? 1.4 : 1}"/>` +
    `<rect x="${f2(x + w * .12)}" y="${f2(y)}" width="${f2(w * .76)}" height="1.2" fill="url(#cardLine)" opacity=".7"/>` +
    `</g>`;
}
const cardDefs = (x0, w0) => `
<linearGradient id="cardBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#121918"/><stop offset="1" stop-color="#070909"/></linearGradient>
<radialGradient id="cardGlow" cx="0" cy="0" r="1.1" gradientUnits="objectBoundingBox"><stop offset="0" stop-color="${TEAL}" stop-opacity=".20"/><stop offset=".55" stop-color="${TEAL}" stop-opacity="0"/></radialGradient>
<linearGradient id="cardLine" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${TEAL_L}" stop-opacity="0"/><stop offset=".5" stop-color="${TEAL_L}"/><stop offset="1" stop-color="${TEAL_L}" stop-opacity="0"/></linearGradient>
<linearGradient id="segOn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${TEAL_L}"/><stop offset=".7" stop-color="${TEAL}"/></linearGradient>
<linearGradient id="pctFill" x1="0" y1="0" x2="0" y2="1"><stop offset=".2" stop-color="#fff"/><stop offset="1" stop-color="${TEAL_L}"/></linearGradient>
<linearGradient id="barOn" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${TEAL}"/><stop offset="1" stop-color="${TEAL_L}"/></linearGradient>
<filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`;

/* ============================================================================
   1) WIDGET UTAMA  (kanvas 390 x 844, proporsi layar ponsel)
   ========================================================================== */
function renderWidget() {
  const W = 390, H = 844, cq = W / 100;
  const out = [];

  /* --- Kotak toska + hari + tanggal --- */
  const tile = { x: W * .05, y: H * .031, w: W * .222, h: H * .222 };
  tile.r = tile.x + tile.w; tile.b = tile.y + tile.h;
  const dayName = DAYS[NOW.dow];
  out.push(`<rect x="${f2(tile.x)}" y="${f2(tile.y)}" width="${f2(tile.w)}" height="${f2(tile.h)}" fill="url(#tileG)"/>`);
  out.push(`<text x="${f2(tile.x + tile.w * .08)}" y="${f2(tile.y + tile.h * .06 + 12.4)}" font-family="${FONT}" font-size="${f2(3.5 * cq)}" font-weight="800" letter-spacing="${f2(.14 * 3.5 * cq)}" fill="#fff">${dayName}</text>`);
  out.push(`<rect x="${f2(tile.x + tile.w * .08)}" y="${f2(tile.y + tile.h * .06 + 31.6)}" width="${f2(dayName.length * 5.6)}" height="2" rx="1" fill="#fff" fill-opacity=".85"/>`);
  out.push(`<text x="${f2(tile.r - tile.w * .05)}" y="${f2(tile.b - 6.8)}" text-anchor="end" font-family="${FONT_BLACK}" font-weight="900" font-size="${f2(12.2 * cq)}" letter-spacing="${f2(-.06 * 12.2 * cq)}" fill="#fff">${NOW.d}<tspan font-size="${f2(3.8 * cq)}" dy="${f2(-25.5)}" letter-spacing="${f2(-.02 * 3.8 * cq)}">${ordinal(NOW.d)}</tspan></text>`);

  /* --- Tahun (tepi kiri tinta = tepi kiri kotak) --- */
  const CAP = .716;
  const yfs = W * .056, yCap = CAP * yfs;
  const yTop = tile.b + 1.5 * cq;
  out.push(`<text transform="translate(${f2(tile.x + yCap)} ${f2(yTop)}) rotate(-90)" text-anchor="end" font-family="${FONT_BLACK}" font-weight="900" font-size="${f2(yfs)}" letter-spacing="${f2(.05 * yfs)}" fill="#fff">${NOW.y}</text>`);

  /* --- Bulan: tinggi huruf = sisa lebar kotak; panjang = bawah kotak s/d dasar panel progres --- */
  const GAP = W * .022;
  const monthCap = Math.max(W * .05, tile.w - yCap - GAP);
  const stroke = 1.2;                                  /* tepi tipis agar huruf lebih tebal */
  const fs = (monthCap - stroke) / CAP;
  const xBase = tile.x + yCap + GAP + monthCap - stroke / 2;   /* garis dasar huruf (tepi kanan) */
  const Y1 = tile.b + W * .015;
  const trkBottom = H - ((1 - .061 - .88) * H + .7 * cq);
  const Y2 = trkBottom;
  const Hm = Y2 - Y1;
  const mname = MONTHS[NOW.m], n = mname.length;
  const len = [...mname].map(c => (ADV[c] || 700) / 1000 * fs * .94);
  const S = len.reduce((a, b) => a + b, 0);
  const gmin = monthCap * .07, gmax = monthCap * .5, KMAX = 1.45;
  let k = 1, g = (Hm - S) / (n - 1);
  if (g > gmax) { k = Math.min(KMAX, (Hm - (n - 1) * gmax) / S); g = (Hm - k * S) / (n - 1); }
  else if (g < gmin) { k = (Hm - (n - 1) * gmin) / S; g = gmin; }
  let off = 0;
  [...mname].forEach((c, i) => {
    const cy = Y2 - off - k * len[i] / 2;
    out.push(`<text transform="translate(${f2(xBase)} ${f2(cy)}) rotate(-90) scale(${k.toFixed(4)} 1)" text-anchor="middle" font-family="${FONT}" font-weight="900" font-size="${f2(fs)}" fill="#fff" stroke="#fff" stroke-width="${stroke}" stroke-linejoin="round">${c}</text>`);
    off += k * len[i] + g;
  });

  /* --- Jam (digit SVG; dasar tetap, puncak sejajar tepi atas kotak) --- */
  const clockTop = tile.y + W * .005;
  const tlTop = H * .14, tlLeft = W * .33, tlW = W * .62, tlH = H * .695;
  const clockBottom = tlTop + W * .12;
  const clockH = clockBottom - clockTop, clockW = clockH * 552 / 526;
  const xs = [0, 128, 324, 452];
  const hhmm = pad2(NOW.hh) + pad2(NOW.mm);
  out.push(`<svg x="${f2(tlLeft)}" y="${f2(clockTop)}" width="${f2(clockW)}" height="${f2(clockH)}" viewBox="0 0 552 526" overflow="visible">` +
    `<g fill="none" stroke="#fff" stroke-width="38" stroke-linejoin="miter" stroke-linecap="butt">` +
    [...hhmm].map((c, i) => `<use href="#d${c}" x="${xs[i]}"/>`).join('') + `</g>` +
    `<circle cx="276" cy="140" r="19" fill="#fff"/><circle cx="276" cy="386" r="19" fill="#fff"/></svg>`);
  out.push(`<text x="${f2(tlLeft + clockW + 8)}" y="${f2(clockBottom - 2)}" font-family="${FONT}" font-weight="700" font-size="${f2(2 * cq)}" letter-spacing=".12em" fill="#6f7f7d">DIPERBARUI</text>`);
  if (TZ_LABEL) out.push(`<text x="${f2(tlLeft + clockW + 8)}" y="${f2(clockBottom - 2 - 10.5)}" font-family="${FONT}" font-weight="800" font-size="${f2(2.6 * cq)}" letter-spacing=".1em" fill="#8fa3a1">${esc(TZ_LABEL)}</text>`);

  /* --- Timeline: kutipan + task --- */
  const entriesTop = tlTop + 16 * cq, entriesBottom = tlTop + tlH;
  const flex = [1.12, ...TASKS.map(() => 1)];
  const flexSum = flex.reduce((a, b) => a + b, 0);
  const unit = (entriesBottom - entriesTop) / flexSum;
  const rail = tlLeft + 2.6 * cq, textX = tlLeft + tlW * .125;
  const m = 4.4 * cq, gap = .8 * cq, hsTask = 3.1 * cq;
  const doneSet = new Set(cur.done);
  let y0 = entriesTop;
  const entries = [{ quote: true }, ...TASKS.map((t, i) => ({ t, i }))];
  entries.forEach((e, idx) => {
    const h = unit * flex[idx], y1 = y0 + h, last = idx === entries.length - 1;
    const quote = !!e.quote;
    const hs = quote ? 4.3 * cq : hsTask;
    const mh = quote ? 2.7 * cq : m / 2;
    const done = !quote && doneSet.has(e.i);
    /* garis penghubung */
    if (!last) {
      out.push(`<line x1="${f2(rail)}" x2="${f2(rail)}" y1="${f2(y0 + hs * .54 + mh + gap)}" y2="${f2(y1 - (gap + m / 2 - hsTask * .54))}" stroke="#fff" stroke-width="2"/>`);
    }
    /* penanda */
    const cy = y0 + hs * .54;
    if (quote) {
      const s = 5.4 * cq, pts = [[50, 0], [62, 22], [85, 12], [80, 38], [100, 50], [79, 63], [87, 88], [61, 78], [50, 100], [38, 78], [13, 88], [21, 62], [0, 50], [20, 37], [13, 12], [39, 22]]
        .map(([px, py]) => `${f2(rail - s / 2 + px / 100 * s)},${f2(cy - s / 2 + py / 100 * s)}`).join(' ');
      out.push(`<polygon points="${pts}" fill="url(#starG)"/>`);
    } else {
      const r = m / 2 - 1;
      out.push(`<circle cx="${f2(rail)}" cy="${f2(cy)}" r="${f2(r + 1 + .55 * cq)}" fill="#000"/>`);
      out.push(`<circle cx="${f2(rail)}" cy="${f2(cy)}" r="${f2(r)}" fill="${done ? TEAL : '#0a0a0a'}" stroke="#fff" stroke-width="2"${done ? ' filter="url(#glow)"' : ''}/>`);
      if (done) out.push(`<path d="M${f2(rail - r * .42)} ${f2(cy + r * .02)}L${f2(rail - r * .1)} ${f2(cy + r * .38)}L${f2(rail + r * .46)} ${f2(cy - r * .36)}" fill="none" stroke="#00201e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`);
      else out.push(`<circle cx="${f2(rail)}" cy="${f2(cy)}" r="${f2(r * .36)}" fill="${TEAL}"/>`);
    }
    /* teks */
    const hText = quote ? QUOTE.author : e.t.name;
    const dText = quote ? `"${QUOTE.text}"` : (e.t.detail || '');
    const hy = y0 + hs * .8865;
    const dfs = quote ? 2.55 * cq : 2.15 * cq, dlh = quote ? 1.42 : 1.45;
    const dTop = y0 + hs * 1.08 + tlW * .018;
    const col = done ? '#858585' : '#fff';
    const deco = done ? ' text-decoration="line-through"' : '';
    out.push(`<text x="${f2(textX)}" y="${f2(hy)}" font-family="${FONT}" font-weight="800" font-size="${f2(hs)}" letter-spacing="${f2(.015 * hs)}" fill="${col}"${deco}>${esc(hText)}</text>`);
    const maxChars = Math.floor((tlLeft + tlW - textX) / (dfs * .5));
    wrap(dText, maxChars).forEach((ln, li) => {
      const by = dTop + li * dfs * dlh + ((dlh - 1.117) / 2 + .905) * dfs;
      out.push(`<text x="${f2(textX)}" y="${f2(by)}" font-family="${FONT}" font-weight="500" font-size="${f2(dfs)}" letter-spacing="${f2(.015 * dfs)}" fill="${done ? '#858585' : '#eee'}"${deco}>${esc(ln)}</text>`);
    });
    y0 = y1;
  });

  /* --- Panel progres (ketuk -> history.svg lewat tautan di README) --- */
  const total = TASKS.length, done = cur.done.length;
  const pct = Math.round(done / total * 100);
  const msg = pct === 100 ? 'Semua selesai, mantap!' : pct >= 60 ? 'Sedikit lagi, semangat!' : pct > 0 ? 'Bagus, terus lanjut' : 'Ayo mulai harimu';
  const cx = tlLeft, cw = tlW, ch = 74, cyTop = trkBottom - ch;
  out.push(card(cx, cyTop, cw, ch, 3.2 * cq, 'trk', true, pct === 100));
  out.push(`<circle cx="${f2(cx + 11.7 + 3)}" cy="${f2(cyTop + 9.4 + 3.5)}" r="3" fill="${TEAL_L}" filter="url(#glow)"/>`);
  out.push(`<text x="${f2(cx + 11.7 + 11)}" y="${f2(cyTop + 9.4 + 7)}" font-family="${FONT}" font-weight="700" font-size="${f2(2 * cq)}" letter-spacing="${f2(.14 * 2 * cq)}" fill="#8fa3a1">PROGRES HARI INI</text>`);
  out.push(`<text x="${f2(cx + cw - 11.7 - 11)}" y="${f2(cyTop + 9.4 + 7)}" text-anchor="end" font-family="${FONT}" font-weight="700" font-size="${f2(2 * cq)}" letter-spacing="${f2(.06 * 2 * cq)}" fill="#9aa8a6"><tspan font-weight="900" font-size="${f2(2.7 * cq)}" fill="#fff">${done}</tspan>/${total} SELESAI</text>`);
  out.push(`<path d="M${f2(cx + cw - 11.7 - 4.5)} ${f2(cyTop + 9.4 + 2)}l4 4.3l-4 4.3" fill="none" stroke="${TEAL_L}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>`);
  const baseY = cyTop + ch - 10.1 - 2;
  out.push(`<text x="${f2(cx + 11.7)}" y="${f2(baseY)}" font-family="${FONT_BLACK}" font-weight="900" font-size="${f2(10.5 * cq)}" letter-spacing="${f2(-.03 * 10.5 * cq)}" fill="url(#pctFill)">${pct}<tspan font-size="${f2(4.2 * cq)}" dy="${f2(-15)}" letter-spacing="0">%</tspan></text>`);
  const segX = cx + 11.7 + 19 * cq + 11.7, segW = cx + cw - 11.7 - segX, sg = 1.1 * cq;
  const sw = (segW - sg * (total - 1)) / total, sh = 3.6 * cq, sy = cyTop + 9.4 + 7 + 9;
  for (let i = 0; i < total; i++) {
    const on = i < done, x = segX + i * (sw + sg);
    out.push(on
      ? `<rect x="${f2(x)}" y="${f2(sy)}" width="${f2(sw)}" height="${f2(sh)}" rx="${f2(1.2 * cq)}" fill="url(#segOn)" stroke="#fff" stroke-opacity=".35" stroke-width=".8" filter="url(#glow)"/>`
      : `<rect x="${f2(x)}" y="${f2(sy)}" width="${f2(sw)}" height="${f2(sh)}" rx="${f2(1.2 * cq)}" fill="#1b2221" stroke="#2a3433" stroke-width=".8"/>`);
  }
  out.push(`<text x="${f2(segX)}" y="${f2(baseY - 2)}" font-family="${FONT}" font-weight="700" font-size="${f2(2.2 * cq)}" letter-spacing="${f2(.06 * 2.2 * cq)}" fill="${TEAL_L}">${esc(msg)}</text>`);

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Widget timeline harian: ${dayName} ${NOW.d} ${mname} ${NOW.y}, ${done} dari ${total} task selesai">
<defs>
<linearGradient id="tileG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#00a69d"/><stop offset=".55" stop-color="#008f87"/><stop offset="1" stop-color="#001c1b"/></linearGradient>
<linearGradient id="starG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#55e4db"/><stop offset=".6" stop-color="#00a99f"/><stop offset="1" stop-color="#007a73"/></linearGradient>
${cardDefs()}
${digitDefs()}
</defs>
<rect width="${W}" height="${H}" fill="#000"/>
${out.join('\n')}
</svg>
`;
}

/* ============================================================================
   2) LAMAN RIWAYAT  (lebar 390, tinggi mengikuti isi)
   ========================================================================== */
const IC = {
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  fire: '<path d="M12 3c1 4 5 5.5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>',
  bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
  trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0zM8 6H4v1a4 4 0 0 0 4 4M16 6h4v1a4 4 0 0 1-4 4M12 13v4M8 20h8M10 17h4"/>'
};

function chartSVG(days, N, selD, todayD, avg, tracked) {
  const VW = 360, VH = 178, pl = 28, pr = 6, pt = 12, pb = 24, cw = VW - pl - pr, chh = VH - pt - pb, slot = cw / N, bw = Math.max(3, slot * .64);
  const T = 'font-family="' + FONT + '" font-size="8.5" font-weight="700"';
  let s = '';
  [0, 25, 50, 75, 100].forEach(v => {
    const y = pt + chh * (1 - v / 100);
    s += `<line x1="${pl}" x2="${VW - pr}" y1="${y}" y2="${y}" stroke="${v === 0 ? '#2a3433' : '#1a2221'}" stroke-width=".8"${v && v < 100 ? ' stroke-dasharray="2 3"' : ''}/>`;
    s += `<text x="${pl - 5}" y="${y + 3}" text-anchor="end" ${T} fill="#6f7f7d">${v}</text>`;
  });
  days.forEach(o => {
    const d = o.d, x = pl + (d - 1) * slot + (slot - bw) / 2;
    s += `<rect x="${f2(x)}" y="${pt}" width="${f2(bw)}" height="${chh}" rx="${f2(bw * .35)}" fill="#0e1413"${o.future ? ' opacity=".5"' : ''}/>`;
    if (o.has) {
      const h = Math.max(o.pct / 100 * chh, 2), y = pt + chh - h;
      if (o.pct === 0) s += `<rect x="${f2(x)}" y="${f2(pt + chh - 2.4)}" width="${f2(bw)}" height="2.4" rx="1" fill="#33403e"/>`;
      else s += `<rect x="${f2(x)}" y="${f2(y)}" width="${f2(bw)}" height="${f2(h)}" rx="${f2(bw * .35)}" fill="url(#${o.pct === 100 ? 'hp' : 'hb'})"${o.pct === 100 ? ' filter="url(#gl)"' : ''}/>`;
    }
    if (d === todayD) s += `<rect x="${f2(x - 1)}" y="${pt - 1}" width="${f2(bw + 2)}" height="${chh + 2}" rx="${f2(bw * .4)}" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width=".9"/>`;
  });
  if (tracked) {
    const ay = pt + chh * (1 - avg / 100);
    s += `<line x1="${pl}" x2="${VW - pr}" y1="${f2(ay)}" y2="${f2(ay)}" stroke="#fff" stroke-opacity=".55" stroke-width="1" stroke-dasharray="4 3"/>`;
    const ly = ay < pt + 12 ? ay + 10 : ay - 3.5;
    s += `<text x="${VW - pr}" y="${f2(ly)}" text-anchor="end" font-family="${FONT}" font-weight="700" font-size="8" fill="#fff">RATA-RATA ${avg}%</text>`;
  }
  days.forEach(o => {
    const d = o.d;
    if (d === 1 || d % 5 === 0 || d === todayD || (d === N && N % 5 >= 2)) {
      const x = pl + (d - 1) * slot + slot / 2;
      s += `<text x="${f2(x)}" y="${VH - 7}" text-anchor="middle" ${T} fill="${d === todayD ? '#fff' : '#6f7f7d'}">${d}</text>`;
    }
  });
  return `<svg x="0" y="0" width="100%" viewBox="0 0 ${VW} ${VH}"><defs>
<linearGradient id="hb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#55e4db"/><stop offset="1" stop-color="#00a99f"/></linearGradient>
<linearGradient id="hp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a8f7f1"/><stop offset="1" stop-color="#17c9bd"/></linearGradient>
<filter id="gl" x="-60%" y="-30%" width="220%" height="160%"><feGaussianBlur stdDeviation="2.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>${s}</svg>`;
}

function ringSVG(cx, cy, r, pct) {
  const C = 2 * Math.PI * r, sw = r * .25;
  return `<circle cx="${f2(cx)}" cy="${f2(cy)}" r="${f2(r)}" fill="none" stroke="#18201f" stroke-width="${f2(sw)}"/>` +
    `<circle cx="${f2(cx)}" cy="${f2(cy)}" r="${f2(r)}" fill="none" stroke="url(#ringG)" stroke-width="${f2(sw)}" stroke-linecap="round" stroke-dasharray="${f2(pct / 100 * C)} ${f2(C)}" transform="rotate(-90 ${f2(cx)} ${f2(cy)})" filter="url(#glow)"/>` +
    `<text x="${f2(cx)}" y="${f2(cy + r * .22)}" text-anchor="middle" font-family="${FONT_BLACK}" font-weight="900" font-size="${f2(r * .6)}" fill="#fff">${pct}<tspan font-size="${f2(r * .3)}" fill="#9aa8a6">%</tspan></text>`;
}

function renderHistory() {
  const W = 390, PAD = 19.5, CW = W - PAD * 2, y = { v: 34 };
  const out = [];
  const ty = NOW.y, tm = NOW.m, td = NOW.d, N = daysIn(ty, tm);
  const days = [];
  for (let d = 1; d <= N; d++) {
    const rec = recOf(ty, tm, d), future = d > td;
    const has = !future && !!rec;
    days.push({ d, rec, future, has, pct: has ? pctOf(rec) : 0, done: has ? doneOf(rec) : 0, total: has ? rec.tasks.length : 0 });
  }
  const tr = days.filter(o => o.has);
  const sumDone = tr.reduce((a, o) => a + o.done, 0), sumTotal = tr.reduce((a, o) => a + o.total, 0);
  const avg = sumTotal ? Math.round(sumDone / sumTotal * 100) : 0;
  const perfect = tr.filter(o => o.pct === 100).length;
  let best = null; tr.forEach(o => { if (!best || o.pct > best.pct) best = o; });
  const activeDays = tr.filter(o => o.done > 0).length;
  /* streak sempurna berturut-turut sampai hari ini (hari ini boleh belum selesai) */
  let st = 0; { let dd = new Date(Date.UTC(ty, tm, td)); if (pctOf(recOf(dd.getUTCFullYear(), dd.getUTCMonth(), dd.getUTCDate())) < 100) dd.setUTCDate(dd.getUTCDate() - 1);
    while (st < 4000 && pctOf(recOf(dd.getUTCFullYear(), dd.getUTCMonth(), dd.getUTCDate())) === 100) { st++; dd.setUTCDate(dd.getUTCDate() - 1); } }
  const avgPerDay = tr.length ? sumDone / tr.length : 0;

  /* Header */
  out.push(`<circle cx="${PAD + 4}" cy="${y.v + 6}" r="4" fill="${TEAL_L}" filter="url(#glow)"/>`);
  out.push(`<text x="${PAD + 16}" y="${y.v + 12}" font-family="${FONT}" font-weight="900" font-size="${f2(4.6 * W / 100)}" letter-spacing=".04em" fill="#fff">RIWAYAT TASK</text>`);
  out.push(`<text x="${PAD + 16}" y="${y.v + 27}" font-family="${FONT}" font-weight="700" font-size="8.6" letter-spacing=".12em" fill="#8fa3a1">PROGRES HARI KE HARI</text>`);
  y.v += 58;
  /* Bulan */
  out.push(`<text x="${W / 2}" y="${y.v + 22}" text-anchor="middle" font-family="${FONT}" font-weight="900" font-size="${f2(6.6 * W / 100)}" letter-spacing=".14em" fill="#fff">${MONTHS[tm]}</text>`);
  out.push(`<text x="${W / 2}" y="${y.v + 40}" text-anchor="middle" font-family="${FONT}" font-weight="700" font-size="10" letter-spacing=".4em" fill="${TEAL_L}">${ty}</text>`);
  y.v += 58;

  /* Ringkasan */
  const sH = 150;
  out.push(card(PAD, y.v, CW, sH, 15.6));
  const cap = (x, yy, t) => `<circle cx="${f2(x + 3)}" cy="${f2(yy - 3)}" r="3" fill="${TEAL_L}" filter="url(#glow)"/><text x="${f2(x + 11)}" y="${f2(yy)}" font-family="${FONT}" font-weight="800" font-size="8.6" letter-spacing=".14em" fill="#8fa3a1">${t}</text>`;
  out.push(cap(PAD + 15, y.v + 24, 'RINGKASAN BULAN'));
  out.push(ringSVG(PAD + 15 + 46, y.v + 24 + 14 + 46 + 8, 38, avg));
  const rx = PAD + 15 + 46 * 2 + 18;
  out.push(`<text x="${f2(rx)}" y="${f2(y.v + 82)}" font-family="${FONT_BLACK}" font-weight="900" font-size="${f2(7.4 * W / 100)}" letter-spacing="-.02em" fill="#fff">${sumDone}<tspan font-family="${FONT}" font-weight="700" font-size="${f2(3.2 * W / 100)}" fill="#9aa8a6" letter-spacing=".04em"> / ${sumTotal} task selesai</tspan></text>`);
  const l1 = tr.length ? `Tercatat ${tr.length} hari, aktif ${activeDays} hari.` : 'Belum ada data di bulan ini.';
  out.push(`<text x="${f2(rx)}" y="${f2(y.v + 102)}" font-family="${FONT}" font-weight="600" font-size="9.6" fill="#b5c2c0">${l1}</text>`);
  if (best && best.pct > 0) out.push(`<text x="${f2(rx)}" y="${f2(y.v + 116)}" font-family="${FONT}" font-weight="600" font-size="9.6" fill="#b5c2c0">Terbaik: <tspan fill="${TEAL_L}" font-weight="800">${best.d} ${MON_SHORT[tm]} (${best.pct}%)</tspan></text>`);
  y.v += sH + 10;

  /* Statistik 2 x 2 */
  const sw = (CW - 10) / 2, sh = 96;
  const stats = [
    ['star', String(perfect), 'hari', 'HARI SEMPURNA 100%'],
    ['fire', String(st), 'hari', 'STREAK SEMPURNA'],
    ['bolt', avgPerDay.toFixed(1).replace('.', ','), 'task', 'RATA-RATA PER HARI'],
    ['trophy', String(best ? best.pct : 0), '%', 'HARI TERBAIK']
  ];
  stats.forEach((s, i) => {
    const x = PAD + (i % 2) * (sw + 10), yy = y.v + Math.floor(i / 2) * (sh + 10);
    out.push(card(x, yy, sw, sh, 14, '', false));
    out.push(`<circle cx="${f2(x + 12.5 + 15)}" cy="${f2(yy + 12.5 + 15)}" r="15" fill="${TEAL}" fill-opacity=".14" stroke="${TEAL_L}" stroke-opacity=".35"/>`);
    out.push(`<svg x="${f2(x + 12.5 + 7.5)}" y="${f2(yy + 12.5 + 7.5)}" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="${TEAL_L}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${IC[s[0]]}</svg>`);
    out.push(`<text x="${f2(x + 12.5)}" y="${f2(yy + 70)}" font-family="${FONT_BLACK}" font-weight="900" font-size="${f2(7 * W / 100)}" letter-spacing="-.02em" fill="#fff">${s[1]}<tspan font-family="${FONT}" font-weight="700" font-size="10" fill="#9aa8a6" dx="3">${s[2]}</tspan></text>`);
    out.push(`<text x="${f2(x + 12.5)}" y="${f2(yy + sh - 11)}" font-family="${FONT}" font-weight="700" font-size="8.2" letter-spacing=".1em" fill="#8fa3a1">${s[3]}</text>`);
  });
  y.v += sh * 2 + 10 + 10;

  /* Diagram batang harian */
  const chartW = CW - 29.6, chartH = chartW * 178 / 360, cH = 15 + 14 + 14 + chartH + 14 + 22;
  out.push(card(PAD, y.v, CW, cH, 15.6));
  out.push(cap(PAD + 15, y.v + 24, 'DIAGRAM PROGRES HARIAN'));
  out.push(`<text x="${f2(PAD + CW - 15)}" y="${f2(y.v + 24)}" text-anchor="end" font-family="${FONT}" font-weight="800" font-size="8.6" letter-spacing=".14em" fill="#8fa3a1">${MON_SHORT[tm].toUpperCase()} ${ty}</text>`);
  out.push(`<svg x="${f2(PAD + 14.8)}" y="${f2(y.v + 36)}" width="${f2(chartW)}" height="${f2(chartH)}" viewBox="0 0 360 178">${chartSVG(days, N, td, td, avg, tr.length > 0).replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '')}</svg>`);
  const ly = y.v + 36 + chartH + 14;
  const leg = [['PROGRES', 'url(#hb)'], ['100%', 'url(#hp)'], ['BAYANG', '#0e1413'], ['RATA-RATA', '']];
  let lx = PAD + 15;
  leg.forEach(([t, f], i) => {
    if (i < 3) out.push(`<rect x="${f2(lx)}" y="${f2(ly - 8)}" width="9" height="9" rx="2.5" fill="${f}"${t === 'BAYANG' ? ' stroke="#2a3433"' : ''}/>`);
    else out.push(`<line x1="${f2(lx)}" x2="${f2(lx + 12)}" y1="${f2(ly - 3.5)}" y2="${f2(ly - 3.5)}" stroke="#fff" stroke-opacity=".6" stroke-width="1.2" stroke-dasharray="3 2"/>`);
    out.push(`<text x="${f2(lx + (i < 3 ? 13 : 16))}" y="${f2(ly)}" font-family="${FONT}" font-weight="700" font-size="7.8" letter-spacing=".06em" fill="#8fa3a1">${t}</text>`);
    lx += 13 + t.length * 5.6 + 12;
  });
  y.v += cH + 10;

  /* Detail hari ini */
  const rec = recOf(ty, tm, td);
  const rowH = 32, dH = 58 + (rec ? rec.tasks.length * rowH : 40) + 12;
  out.push(card(PAD, y.v, CW, dH, 15.6));
  out.push(`<text x="${f2(PAD + 15)}" y="${f2(y.v + 30)}" font-family="${FONT}" font-weight="900" font-size="${f2(4.2 * W / 100)}" letter-spacing=".06em" fill="#fff">${DAYS[NOW.dow]}, ${td} ${MON_SHORT[tm].toUpperCase()}</text>`);
  out.push(`<text x="${f2(PAD + 15)}" y="${f2(y.v + 45)}" font-family="${FONT}" font-weight="700" font-size="9.4" fill="#9aa8a6">${rec ? doneOf(rec) + ' dari ' + rec.tasks.length + ' task selesai' : 'Tidak ada data'}</text>`);
  out.push(`<text x="${f2(PAD + CW - 15)}" y="${f2(y.v + 44)}" text-anchor="end" font-family="${FONT_BLACK}" font-weight="900" font-size="${f2(9 * W / 100)}" letter-spacing="-.03em" fill="url(#pctFill)">${pctOf(rec)}<tspan font-size="${f2(3.6 * W / 100)}" dy="-15">%</tspan></text>`);
  if (rec) rec.tasks.forEach((t, i) => {
    const yy = y.v + 58 + i * rowH;
    if (i) out.push(`<line x1="${f2(PAD + 15)}" x2="${f2(PAD + CW - 15)}" y1="${f2(yy)}" y2="${f2(yy)}" stroke="#1d2625"/>`);
    const cyy = yy + rowH / 2, cxx = PAD + 15 + 10.5;
    if (t.d) {
      out.push(`<circle cx="${f2(cxx)}" cy="${f2(cyy)}" r="10.5" fill="${TEAL}" filter="url(#glow)"/>`);
      out.push(`<path d="M${f2(cxx - 4.4)} ${f2(cyy + .2)}L${f2(cxx - 1.2)} ${f2(cyy + 3.6)}L${f2(cxx + 4.6)} ${f2(cyy - 3.4)}" fill="none" stroke="#00201e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`);
    } else out.push(`<circle cx="${f2(cxx)}" cy="${f2(cyy)}" r="9.8" fill="none" stroke="#4b5857" stroke-width="1.6"/>`);
    out.push(`<text x="${f2(PAD + 15 + 21 + 12)}" y="${f2(cyy + 4)}" font-family="${FONT}" font-weight="800" font-size="11.6" fill="${t.d ? '#fff' : '#8c9a98'}">${esc(t.n)}</text>`);
    out.push(`<text x="${f2(PAD + CW - 15)}" y="${f2(cyy + 3.5)}" text-anchor="end" font-family="${FONT}" font-weight="800" font-size="9" letter-spacing=".04em" fill="#9aa8a6">${t.d ? 'SELESAI' : 'BELUM'}</text>`);
  });
  y.v += dH + 10;

  /* Progres per task (bulan ini) */
  const map = new Map();
  tr.forEach(o => o.rec.tasks.forEach(t => { const m = map.get(t.n) || { done: 0, total: 0 }; m.done += t.d; m.total++; map.set(t.n, m); }));
  const rows = [...map.entries()].sort((a, b) => b[1].done / b[1].total - a[1].done / a[1].total || b[1].total - a[1].total);
  const pH = 44 + Math.max(rows.length, 1) * 36 + 8;
  out.push(card(PAD, y.v, CW, pH, 15.6));
  out.push(cap(PAD + 15, y.v + 24, 'PER TASK BULAN INI'));
  rows.forEach(([nm, m], i) => {
    const p = Math.round(m.done / m.total * 100), yy = y.v + 44 + i * 36;
    out.push(`<text x="${f2(PAD + 15)}" y="${f2(yy + 11)}" font-family="${FONT}" font-weight="800" font-size="11">${esc(nm)}</text>`.replace('<text ', '<text fill="#fff" '));
    out.push(`<text x="${f2(PAD + CW - 15)}" y="${f2(yy + 11)}" text-anchor="end" font-family="${FONT}" font-weight="700" font-size="9" letter-spacing=".04em" fill="#9aa8a6">${m.done}/${m.total} HARI · ${p}%</text>`);
    out.push(`<rect x="${f2(PAD + 15)}" y="${f2(yy + 18)}" width="${f2(CW - 30)}" height="6" rx="3" fill="#1b2221"/>`);
    if (p > 0) out.push(`<rect x="${f2(PAD + 15)}" y="${f2(yy + 18)}" width="${f2((CW - 30) * p / 100)}" height="6" rx="3" fill="url(#barOn)"/>`);
  });
  y.v += pH + 24;

  const H = Math.ceil(y.v);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Riwayat task ${MONTHS[tm]} ${ty}: ${sumDone} dari ${sumTotal} task selesai">
<defs>
<radialGradient id="topGlow" cx=".5" cy="0" r=".6"><stop offset="0" stop-color="${TEAL}" stop-opacity=".22"/><stop offset="1" stop-color="${TEAL}" stop-opacity="0"/></radialGradient>
<linearGradient id="ringG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${TEAL_L}"/><stop offset="1" stop-color="${TEAL}"/></linearGradient>
${cardDefs()}
</defs>
<rect width="${W}" height="${H}" fill="#000"/>
<rect width="${W}" height="${f2(H * .38)}" fill="url(#topGlow)"/>
${out.join('\n')}
</svg>
`;
}

fs.writeFileSync(OUT_WIDGET, renderWidget());
fs.writeFileSync(OUT_HISTORY, renderHistory());
console.log(`OK ${todayKey} ${pad2(NOW.hh)}:${pad2(NOW.mm)} ${TZ} – ${cur.done.length}/${TASKS.length} task selesai`);
