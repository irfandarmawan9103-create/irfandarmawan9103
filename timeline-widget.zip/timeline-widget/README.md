# Timeline Widget untuk GitHub

Widget harian bergaya wallpaper gelap-toska yang tampil di **README** profil atau repositorimu.
Isinya sama dengan versi HTML: kotak tanggal + hari, tahun dan bulan vertikal (selalu pas selebar kotak), jam tinggi-sempit,
daftar task dengan penanda centang, panel progres, dan **laman riwayat** (ringkasan bulan, statistik, diagram batang harian).

| `widget.svg` | `history.svg` |
|---|---|
| Tampilan utama | Riwayat task bulan berjalan |

GitHub tidak menjalankan JavaScript di README, jadi widget dibuat sebagai **gambar SVG yang dirender ulang otomatis oleh GitHub Actions** (tiap 30 menit, plus saat kamu mencentang task).

---

## Cara pasang (5 langkah)

1. **Buat repositori baru** di GitHub (boleh publik), lalu unggah semua isi folder ini.
   Untuk widget di profil, pakai repositori bernama sama dengan username-mu (`USERNAME/USERNAME`).
2. Buka **Settings → Actions → General → Workflow permissions**, pilih **Read and write permissions**, lalu **Save**.
3. Buka tab **Actions → Update Timeline Widget → Run workflow** sekali untuk membuat gambar pertama.
4. Tempel ini di `README.md` (ganti `USERNAME` dan `REPO`):

```html
<p align="center">
  <a href="https://github.com/USERNAME/REPO/blob/main/history.svg">
    <img src="https://raw.githubusercontent.com/USERNAME/REPO/main/widget.svg" width="320" alt="Timeline widget">
  </a>
</p>
```

   Klik gambar akan membuka `history.svg` (riwayat), sebagai pengganti "klik panel progres".
   Mau menampilkan keduanya berdampingan:

```html
<p align="center">
  <img src="https://raw.githubusercontent.com/USERNAME/REPO/main/widget.svg"  width="300">
  <img src="https://raw.githubusercontent.com/USERNAME/REPO/main/history.svg" width="300">
</p>
```

5. Selesai. Widget memperbarui dirinya sendiri.

---

## Mencentang task

Ada dua cara:

- **Lewat Actions (paling mudah, bisa dari aplikasi GitHub di ponsel):**
  *Actions → Update Timeline Widget → Run workflow*, isi kolom `toggle` dengan nomor task (`2`, atau `1,3` untuk beberapa).
  Menjalankan nomor yang sama lagi akan membatalkan centang.
- **Lewat file:** edit `data/log.json`, tambahkan nomor task (mulai dari 0) ke daftar `done` pada tanggal hari ini.

Reset **00.00** terjadi otomatis: setiap tanggal punya catatannya sendiri di `data/log.json`, jadi hari baru selalu mulai dari nol
dan progres hari kemarin tetap tersimpan untuk riwayat.

## Mengubah isi

Semua ada di `data/config.json`:

```json
{
  "timezone": "Asia/Jakarta",
  "timezoneLabel": "WIB",
  "quote": { "author": "Warren Buffett", "text": "..." },
  "tasks": [ { "name": "Bangun pagi", "detail": "Pukul 05.00" } ]
}
```

- `timezone`: zona waktu IANA (misal `Asia/Makassar`, `Asia/Jayapura`); jam, tanggal, dan reset 00.00 mengikutinya.
- `tasks`: jumlah task bebas; segmen progres dan tinggi daftar menyesuaikan otomatis. Perubahan berlaku untuk hari ini dan seterusnya, hari lampau tidak berubah.

Uji lokal tanpa GitHub:

```bash
node scripts/render.mjs                         # render ulang
node scripts/render.mjs --toggle 2              # centang task ke-2
WIDGET_NOW=2026-10-18T23:59:50+07:00 node scripts/render.mjs   # simulasi waktu tertentu
```

---

## Batasan yang perlu diketahui

- **Jam bukan jam hidup.** SVG di README tidak bisa berdetik. Jam menunjukkan waktu pembaruan terakhir (diberi label *DIPERBARUI*).
  Jadwal Actions juga bisa tertunda beberapa menit saat GitHub sedang sibuk.
- **Cache gambar.** GitHub menyimpan gambar README sementara, jadi perubahan kadang baru terlihat setelah beberapa menit.
- **Riwayat commit.** Tiap pembaruan membuat commit kecil. Perlebar jadwal (`*/30` → `0 * * * *`) kalau terlalu ramai.
- **Font.** Widget memakai font bawaan perangkat (Arial/Helvetica). Huruf bulan dihitung dengan lebar Arial Bold, jadi di perangkat dengan font lain
  lebar kolom tetap pas, tetapi jarak antar huruf bisa sedikit berbeda.

## Versi interaktif (GitHub Pages)

Folder `docs/` berisi `index.html`, yaitu wallpaper aslinya yang interaktif (jam berdetik, centang langsung, riwayat tersimpan di browser).
Aktifkan lewat **Settings → Pages → Deploy from a branch → `main` / `docs`**, lalu buka `https://USERNAME.github.io/REPO/`.
Versi ini menyimpan data di browser masing-masing, terpisah dari `data/log.json`.
